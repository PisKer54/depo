bot.on('ready', () => { // Botumuz açıldığında tetiklenen ready eventimiz.
    
    const degisenaktivite = [ // Değişen aktivitemizin içeriğini tanımladığımız kısım.
    "-yardım.", // Buraya ne istiyorsanız ekleyebilirsiniz. Kullanıcı tercihine bağlı.
     + "Bot Aktif",
    "Harika Komutlar"
    ];
    
    setInterval(() => { // degisenaktivite bölümünü işte burada, setInterval kullanarak aktivite kısmının değişmesini sağlıyoruz.
        const aktivite = Math.floor(Math.random() * (degisenaktivite.length - 1) + 1); // Math.random() fonksiyonu Javascript dilinde, belirttiğiniz sayı aralığında rastgele sayı üretmek için kullanılır.
        bot.user.setActivity(degisenaktivite[oynuyor]); // İşte burada .setActivity() ile botumuzun aktivite (oynuyor) kısmını değiştiriyoruz.
    }, 30000); // 30 saniyede bir değişeceğini belirttik.
});